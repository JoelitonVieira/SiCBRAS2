<?php

$factory->define(App\Questõe::class, function (Faker\Generator $faker) {
    return [

    ];
});
